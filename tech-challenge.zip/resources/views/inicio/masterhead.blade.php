<!-- Masthead-->
<header class="masthead">
    <div class="container">
        <div class="masthead-heading text-uppercase">GitHub Commits Gráficos</div>
        <div class="masthead-subheading">Visualize o número dos seus commits gráficamente!</div>
        <a class="btn btn-outline-primary btn-xl text-uppercase" href="#services">Veja Mais!</a>
    </div>
</header>