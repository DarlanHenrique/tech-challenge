<div class="floating-bar">
    <a class="btn" data-toggle="collapse" title="Acessibilidade" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
        <i class="fas fa-universal-access fa-2x"></i>
    </a>
    <div class="collapse fade-in" id="collapseExample">
        <nav class="floating-menu text-center text-white">
            <h6>Lupa</h6>
            @include('includes.lupa')
            @include('includes.vlibras')
        </nav>
    </div>
</div>