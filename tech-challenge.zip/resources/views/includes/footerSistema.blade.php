<footer class="main-footer">
    <div class="float-right d-none d-sm-inline"></div>
    <strong>Copyright &copy; {{ date('Y') }} <a href="" target="_blank">Laravel Tech Challenge</a>.</strong> Todos direitos
    reservados.
</footer>