<div class="floating-bar">
    <a class="btn" data-toggle="collapse" title="Acessibilidade" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
        <i class="fas fa-universal-access fa-2x"></i>
    </a>
    <div class="collapse fade-in" id="collapseExample">
        <nav class="floating-menu text-center text-white">
            <h6>Lupa</h6>
            <?php echo $__env->make('includes.lupa', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('includes.vlibras', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </nav>
    </div>
</div><?php /**PATH /home/user/Documentos/Projetos/tech-challenge/tech-challenge/resources/views/includes/floatingbar.blade.php ENDPATH**/ ?>