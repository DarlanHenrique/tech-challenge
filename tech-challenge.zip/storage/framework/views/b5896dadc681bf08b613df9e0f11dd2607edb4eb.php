<?php $__env->startPush('scripts'); ?>
<script>
    const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 3000,
        timerProgressBar: true,
        onOpen: (toast) => {
            toast.addEventListener('mouseenter', Swal.stopTimer)
            toast.addEventListener('mouseleave', Swal.resumeTimer)
        }
    })
    
    <?php if(session('success')): ?>
        Toast.fire({
            icon: 'success',
            title: 'Operação concluida com sucesso'
        })
    <?php endif; ?>
</script>
<?php $__env->stopPush(); ?><?php /**PATH /home/user/Documentos/Projetos/tech-challenge/tech-challenge/resources/views/includes/success.blade.php ENDPATH**/ ?>