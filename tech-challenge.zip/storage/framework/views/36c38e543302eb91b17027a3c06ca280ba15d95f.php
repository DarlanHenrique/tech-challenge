<div vw class="enabled">
    <div vw-access-button class="active"></div>
    <div vw-plugin-wrapper>
        <div class="vw-plugin-top-wrapper"></div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
    <script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
    <script>
        new window.VLibras.Widget('https://vlibras.gov.br/app');
    </script> 
<?php $__env->stopPush(); ?><?php /**PATH /home/user/Documentos/Projetos/tech-challenge/tech-challenge/resources/views/includes/vlibras.blade.php ENDPATH**/ ?>