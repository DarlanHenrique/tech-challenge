<footer class="main-footer">
    <div class="float-right d-none d-sm-inline"></div>
    <strong>Copyright &copy; <?php echo e(date('Y')); ?> <a href="" target="_blank">Laravel Tech Challenge</a>.</strong> Todos direitos
    reservados.
</footer><?php /**PATH /home/user/Documentos/Projetos/tech-challenge/tech-challenge/resources/views/includes/footerSistema.blade.php ENDPATH**/ ?>