<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Bem vindo ao sistema <?php echo e(Auth::user()->name); ?>!</h1>
        <div class="content">
            <div>
                <h2 class="text-center">Veja aqui a série temporal de todos os seus commits</h2>
                <?php echo $__env->make('dashboard.commits', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="d-flex justify-content-center pt-3 pb-3">
                    <a href="<?php echo e(route('projects')); ?>" class="btn btn-outline-secondary text-center">Ir para a página de repositórios.</a>
                </div>
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('js/components/dataTable.js')); ?>"></script>
    <script src="<?php echo e(asset('js/components/sweetAlert.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/user/Documentos/Projetos/tech-challenge/tech-challenge/resources/views/dashboard/index.blade.php ENDPATH**/ ?>