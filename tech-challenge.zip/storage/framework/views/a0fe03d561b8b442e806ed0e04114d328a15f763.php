<?php if($body != '' || !($createFirst ?? true)): ?>
    <div class="card">
        <?php if(isset($create) || isset($title)): ?>
            <div class="card-header card-outline card-primary">
                <h3 class="float-left m-0 table-title"><?php echo e($title ?? null); ?></h3>
                <?php if(isset($create)): ?>
                    <div class="float-right mr-2">
                        <div class="input-group input-group-sm">
                            <a href="<?php echo e($create); ?>">
                                <button type="button" class="btn btn-primary">
                                    <b><i class="fas fa-plus-circle"></i> Adicionar</b>
                                </button>
                            </a>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <div class="card-body table-responsive">
            <table  id="example" class="w-100 table table-hover dataTable table-striped">
                <thead class="">
                    <tr>
                        <?php echo e($head ?? null); ?>

                    </tr>
                </thead>
                <tbody>
                    <?php echo e($body ?? null); ?>

                </tbody>
            </table>
        </div>
    </div>
<?php else: ?>
    <div class="text-center" style="color: #949699">
        <i class="fas fa-exclamation-circle" style="font-size: 10em"></i>
        <p class="mb-4 h2">Nenhum item encontrado!</p>
        <a href="<?php echo e($create ?? '#'); ?>">
            <button type="button" class="btn btn-primary">
                <b><i class="fas fa-plus-circle"></i> Adicionar novo item</b>
            </button>
        </a>
    </div>
<?php endif; ?>
<?php /**PATH /home/user/Documentos/Projetos/tech-challenge/tech-challenge/resources/views/components/table.blade.php ENDPATH**/ ?>