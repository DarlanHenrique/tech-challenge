<!-- Masthead-->
<header class="masthead">
    <div class="container">
        <div class="masthead-heading text-uppercase">GitHub Commits Gráficos</div>
        <div class="masthead-subheading">Visualize o número dos seus commits gráficamente!</div>
        <a class="btn btn-outline-primary btn-xl text-uppercase" href="#services">Veja Mais!</a>
    </div>
</header><?php /**PATH /home/user/Documentos/Projetos/tech-challenge/tech-challenge/resources/views/inicio/masterhead.blade.php ENDPATH**/ ?>