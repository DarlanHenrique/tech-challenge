<?php $__env->startSection('content'); ?>
    <div class="container pt-5 mt-5 pb-5 mb-5">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="modal-body">
                
                <div class="flex items-center justify-end mt-4">
                    <a class="btn" href="<?php echo e(url('auth/github')); ?>"
                        style="background: #313131; color: #ffffff; padding: 10px; width: 100%; text-align: center; display: block; border-radius:3px;">
                        Login with GitHub
                    </a>
                </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/user/Documentos/Projetos/tech-challenge/tech-challenge/resources/views/auth/register.blade.php ENDPATH**/ ?>